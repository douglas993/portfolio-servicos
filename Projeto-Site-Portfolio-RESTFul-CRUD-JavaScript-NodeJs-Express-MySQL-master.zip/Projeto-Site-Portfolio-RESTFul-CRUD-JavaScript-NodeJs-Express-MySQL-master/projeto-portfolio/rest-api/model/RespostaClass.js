module.exports = class RespostaClass{
    constructor(){
        this.erro = false;
        this.msg = null;
        this.dados = null;
    }
}
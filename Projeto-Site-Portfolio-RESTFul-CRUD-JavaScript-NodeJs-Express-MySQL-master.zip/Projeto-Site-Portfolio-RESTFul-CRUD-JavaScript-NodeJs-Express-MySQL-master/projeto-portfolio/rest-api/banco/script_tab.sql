CREATE TABLE portfolio (
  id_portfolio INTEGER UNSIGNED  NOT NULL   AUTO_INCREMENT,
  descricao VARCHAR(255)  NULL  ,
  detalhes TEXT  NULL    ,
PRIMARY KEY(id_portfolio));




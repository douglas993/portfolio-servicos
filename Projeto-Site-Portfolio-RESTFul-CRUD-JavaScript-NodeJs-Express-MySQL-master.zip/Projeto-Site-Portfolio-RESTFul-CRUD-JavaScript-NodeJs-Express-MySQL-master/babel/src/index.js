let nome = "teste";
console.log(nome);
let a = 1;
let b = 3;
console.log(a, b);
[b, a] = [a, b];
console.log(a, b);
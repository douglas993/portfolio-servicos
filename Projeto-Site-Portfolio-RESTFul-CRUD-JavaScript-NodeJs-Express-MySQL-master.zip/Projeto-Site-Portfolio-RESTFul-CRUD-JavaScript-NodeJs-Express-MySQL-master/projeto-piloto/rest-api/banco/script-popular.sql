INSERT INTO portfolio(descricao, detalhes) 
VALUES('Desenvolvimento de Websites', 'Tecnologias JavaScript, NodeJs, Express e MySQL');
INSERT INTO portfolio(descricao, detalhes) 
VALUES('Desenvolvimento de APIs', 'Tecnologias JavaScript, NodeJs, Express e MySQL');
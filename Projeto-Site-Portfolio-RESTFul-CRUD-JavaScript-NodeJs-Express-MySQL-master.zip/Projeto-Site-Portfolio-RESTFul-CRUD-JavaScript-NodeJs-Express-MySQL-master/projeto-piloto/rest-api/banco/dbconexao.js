var mysql = require('mysql');

var conexao = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'db_portfolio'
});

module.exports = conexao;

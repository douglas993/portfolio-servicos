import Cliente from './cliente-class';

const objCliente = new Cliente('João');
objCliente.falar();

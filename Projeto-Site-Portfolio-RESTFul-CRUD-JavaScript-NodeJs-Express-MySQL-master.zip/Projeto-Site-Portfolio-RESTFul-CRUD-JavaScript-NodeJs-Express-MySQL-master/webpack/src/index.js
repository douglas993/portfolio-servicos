import {} from './instancia-cliente';
import {} from './promise';
import 'bootstrap';
import base from './css/base.css'
import scss from './scss/base.scss'


const es = "ES2015-const";
console.log(es);